import React from 'react';
import { Brain, Heart, Mail, Phone, Menu, X } from 'lucide-react';
import { useState } from 'react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const teamMembers = [
    {
      name: 'Ayyappadas MT',
      image: 'https://media.licdn.com/dms/image/v2/D4E03AQH7aOdy-2IAww/profile-displayphoto-shrink_800_800/B4EZTa2fdPHcAg-/0/1738838506155?e=1744243200&v=beta&t=21Jw_5M1iB7CVpqg57CmZAzTMXH5UnSg7yBb7gkAOfc'
    },
    {
      name: 'Mithun Krishna',
      image: 'https://media.licdn.com/dms/image/v2/D5603AQEo5wVlgcKpmA/profile-displayphoto-shrink_800_800/B56ZTac2dsGUAo-/0/1738831784687?e=1744243200&v=beta&t=0R_RVvT42YhX3xrJWjAYBLgEhvYLyH0XBPNYwkURLtQ'
    },
    {
      name: 'Shria Nair',
      image: 'https://media.licdn.com/dms/image/v2/D4E03AQG2qwkr3dyN5A/profile-displayphoto-shrink_400_400/profile-displayphoto-shrink_400_400/0/1725295140918?e=1744243200&v=beta&t=iTKWKFTBHClR-8UZvJgd06hFGQKiXzc8a5zaQDGBpx0'
    },
    {
      name: 'Vighnesh H',
      image: 'https://media.licdn.com/dms/image/v2/D5603AQEgzmJJN2_XVA/profile-displayphoto-shrink_800_800/B56ZTazewbHsAk-/0/1738837718302?e=1744243200&v=beta&t=TLjHQ0C_vAL04-Mn763UqbWv5RmxMYzmm5l-vRAx3Jg'
    }
  ];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      {/* Navbar */}
      <nav className="fixed w-full bg-gray-950/95 backdrop-blur-sm z-50 border-b border-red-900/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Brain className="h-8 w-8 text-red-500" />
              <span className="ml-2 text-xl font-bold">QuickCheck AI</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="flex items-center space-x-8">
                <button onClick={() => scrollToSection('about')} className="hover:text-red-500 transition-colors">
                  About Us
                </button>
                <button onClick={() => scrollToSection('contact')} className="hover:text-red-500 transition-colors">
                  Contact Us
                </button>
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-300 hover:text-white">
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-gray-900 border-b border-red-900/20">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <button
                onClick={() => scrollToSection('about')}
                className="block px-3 py-2 w-full text-left hover:bg-red-900/20 transition-colors"
              >
                About Us
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className="block px-3 py-2 w-full text-left hover:bg-red-900/20 transition-colors"
              >
                Contact Us
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-red-500 to-red-800 bg-clip-text text-transparent">
            AI-Powered Medical Diagnosis
          </h1>
          <p className="text-lg text-gray-400 max-w-3xl mx-auto mb-12">
            QuickCheck AI leverages cutting-edge machine learning models to assist doctors in diagnosing diseases with precision and speed. Currently, it offers tools for predicting breast cancer and heart disease.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <a
              href="https://amrita-heart-disease-predictor.streamlit.app/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 bg-red-600 hover:bg-red-700 rounded-lg transition-colors group"
            >
              <Heart className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
              Heart Disease Diagnosis
            </a>
            <a
              href="https://amrita-breast-cancer-diagnosis.streamlit.app/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors group"
            >
              <Brain className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
              Breast Cancer Diagnosis
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-900/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 rounded-lg bg-gray-800/50 hover:bg-gray-800 transition-colors">
              <h3 className="text-xl font-semibold mb-4 text-red-500">High-accuracy ML Models</h3>
              <p className="text-gray-400">State-of-the-art machine learning models trained on extensive medical datasets.</p>
            </div>
            <div className="p-6 rounded-lg bg-gray-800/50 hover:bg-gray-800 transition-colors">
              <h3 className="text-xl font-semibold mb-4 text-red-500">Rapid Analysis</h3>
              <p className="text-gray-400">Quick processing of patient data for immediate diagnostic insights.</p>
            </div>
            <div className="p-6 rounded-lg bg-gray-800/50 hover:bg-gray-800 transition-colors">
              <h3 className="text-xl font-semibold mb-4 text-red-500">Doctor-Centric Design</h3>
              <p className="text-gray-400">Tools specifically designed to complement medical professionals' workflow.</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">About Us</h2>
          <p className="text-gray-400 text-center max-w-4xl mx-auto mb-12">
            We are 2nd-year B.Tech CSE students from Amrita School of Computing, Amrita Vishwa Vidyapeetham, Amritapuri. Our motivation to build this tool stems from our desire to contribute to healthcare by integrating AI technologies into diagnostic workflows, making life-saving tools accessible to doctors worldwide.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {teamMembers.map((member) => (
              <div key={member.name} className="p-4 text-center rounded-lg bg-gray-800/50 hover:bg-gray-800 transition-colors group">
                <div className="mb-4 overflow-hidden rounded-full">
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-32 h-32 mx-auto object-cover transform transition-transform duration-300 group-hover:scale-110"
                    style={{ borderRadius: '50%' }}
                  />
                </div>
                <p className="font-medium">{member.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-900/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Contact Us</h2>
          <div className="flex flex-col items-center space-y-6">
            <a
              href="mailto:quickcheckai007@gmail.com"
              className="flex items-center text-lg hover:text-red-500 transition-colors group"
            >
              <Mail className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
              quickcheckai007@gmail.com
            </a>
            <a
              href="tel:+919447540712"
              className="flex items-center text-lg hover:text-red-500 transition-colors group"
            >
              <Phone className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
              +91 9447540712
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;